﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            using (var context = new ProductShopContext())
            {
                var jsonStr = File.ReadAllText("./../../../Datasets/categories.json");
                Console.WriteLine(ImportCategories(context, jsonStr));
            }
        }

        public static string ImportCategories(ProductShopContext context, string jsonStr)
        {
            var categories = JsonConvert
                .DeserializeObject<IEnumerable<Category>>(jsonStr)
                .Where(c => c.Name?.Length >= 3 && c.Name?.Length <= 15);

            context.Categories.AddRange(categories);
            context.SaveChanges();

            return $"Successfully imported {categories.Count()}";
        }

        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            var users = JsonConvert
                .DeserializeObject<IEnumerable<User>>(inputJson)
                .Where(u => u.LastName?.Length >= 3);

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }
    }
}